library(mice)
# We use iris dataset as an example
missing_dataset <-iris[1:4] #take 4 first columns only
##Assuming that our dataset will have missing values in 3rd and 4th columns (each column has 7 missing values)
missing_dataset <- within(missing_dataset, {
  Petal.Length[1:7] <- NA
  Petal.Width[9:16] <- NA
})
## print out missing dataset
missing_dataset
#Summarize missing data
md.pattern(missing_dataset)

#Running PMM algorim and stored sets of estimated missing values in results
##Input: 1st: our missing dataset, 2nd number of training samples dataset, 3rd method = pmm, 4th seed = random number generator
results <-mice(missing_dataset, m=5,meth='pmm', seed = 1234)
#Apply the results to our missing dataset
imputed_missing_full <- complete(results,1)
imputed_missing_full
